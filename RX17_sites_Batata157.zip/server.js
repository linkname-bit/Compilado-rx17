const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "Batata157";
const DATA_FILE = path.join(__dirname, "visits.json");
const sessions = new Set();

function readVisits(){ try{return JSON.parse(fs.readFileSync(DATA_FILE,"utf8"))}catch{return []} }
function saveVisits(v){fs.writeFileSync(DATA_FILE,JSON.stringify(v,null,2))}
function cookie(req){return (req.headers.cookie||"").split(";").map(x=>x.trim()).find(x=>x.startsWith("admin_session="))?.split("=")[1]}
function isAdmin(req){return sessions.has(cookie(req))}
function send(res,status,body,type="text/html; charset=utf-8"){res.writeHead(status,{"Content-Type":type,"X-Content-Type-Options":"nosniff","Referrer-Policy":"strict-origin-when-cross-origin"});res.end(body)}
function page(file){return fs.readFileSync(path.join(__dirname,file),"utf8")}
const server=http.createServer((req,res)=>{
  const url=new URL(req.url,"http://localhost");
  if(req.method==="GET" && url.pathname==="/"){send(res,200,page("public.html"));return}
  if(req.method==="GET" && url.pathname==="/admin"){send(res,200,page("admin.html"));return}
  if(req.method==="POST" && url.pathname==="/api/visit"){
    let body="";req.on("data",c=>body+=c);req.on("end",()=>{
      try{
        const data=JSON.parse(body||"{}");
        const visits=readVisits();
        visits.unshift({id:crypto.randomUUID(),time:new Date().toISOString(),nickname:String(data.nickname||"Visitante").slice(0,40),page:String(data.page||"/").slice(0,100),device:/Android|iPhone|iPad/i.test(req.headers["user-agent"]||"")?"Celular/Tablet":"Computador",browser:(req.headers["user-agent"]||"").slice(0,180)});
        saveVisits(visits.slice(0,1000));send(res,200,"ok","text/plain");
      }catch{send(res,400,"erro","text/plain")}
    });return;
  }
  if(req.method==="POST" && url.pathname==="/api/login"){
    let body="";req.on("data",c=>body+=c);req.on("end",()=>{
      let password="";try{password=JSON.parse(body).password||""}catch{}
      if(password===ADMIN_PASSWORD){const token=crypto.randomBytes(32).toString("hex");sessions.add(token);res.writeHead(200,{"Set-Cookie":`admin_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400`,"Content-Type":"application/json"});res.end(JSON.stringify({ok:true}));}
      else send(res,401,JSON.stringify({ok:false}),"application/json");
    });return;
  }
  if(req.method==="GET" && url.pathname==="/api/visits"){
    if(!isAdmin(req)){send(res,401,JSON.stringify({error:"unauthorized"}),"application/json");return}
    send(res,200,JSON.stringify(readVisits()),"application/json");return;
  }
  if(req.method==="POST" && url.pathname==="/api/logout"){
    sessions.delete(cookie(req));res.writeHead(200,{"Set-Cookie":"admin_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"});res.end("ok");return;
  }
  send(res,404,"Não encontrado");
});
server.listen(PORT,()=>console.log(`RX17 sites rodando na porta ${PORT}`));
